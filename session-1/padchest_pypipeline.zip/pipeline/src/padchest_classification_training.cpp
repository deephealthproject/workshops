#include <algorithm>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <random>
#include <eddl/serialization/onnx/eddl_onnx.h>
#include "models/models.h"

using namespace ecvl;
using namespace eddl;
using namespace std;
using namespace std::filesystem;

int main()
{
    // Settings
    int epochs = 50;
    int batch_size = 10;
    int num_classes = 2;
    std::vector<int> size{ 256, 256 }; // Size of images
    static std::mt19937 g(std::random_device{}());

    // Define network
    layer in = Input({ 1, size[0], size[1] });
    layer out = VGG16(in, num_classes);
    model net = Model({ in }, { out });

	//net = import_net_from_onnx_file( "padchest_VGG16_adam_lr_0.0001.onnx" ); // if the ONNX file exists

    // Build model
    build(net,
        adam(0.0001), //Optimizer
        { "cross_entropy" }, // Losses
        { "categorical_accuracy" }, // Metrics
        CS_GPU({1,2}, 10, "full_mem"), // Computing service
        true // false To not reinitialize the weights
    );

    //toGPU(net, "low_mem");
    //toGPU(net, {1,2}, 10, "full_mem");

    // View model
    summary(net);
    plot(net, "model.pdf");
    setlogfile(net, "padchest_classification");

    // Create DA transforms for training 
    auto training_augs = make_unique<SequentialAugmentationContainer>(
        AugResizeDim(size, InterpolationType::nearest),
        AugRotate({ -10, 10 }));

    // Validation set resize
    auto validation_augs = make_unique<SequentialAugmentationContainer>(AugResizeDim(size, InterpolationType::nearest));
    // Set the DA
    DatasetAugmentations dataset_augmentations{ {move(training_augs), move(validation_augs), nullptr } };

    // .yml ALREADY CREATED 
    // if you uncomment the lines add -> #include "ecvl/dataset_generator.h"
    // Create the dataset from directory
    //GenerateClassificationDataset c("../../data");
    //Dataset d_classification = c.GetDataset();
    // Dump the Dataset on file
    //d_classification.Dump("../../data/padchest.yml");

    // Read the dataset
    cout << "Reading dataset" << endl;
    DLDataset d("../../data/padchest.yml", batch_size, move(dataset_augmentations), ColorType::GRAY);

    // Prepare tensors which store batch
    tensor x = eddlT::create({ batch_size, d.n_channels_, size[0], size[1] });
    tensor y = eddlT::create({ batch_size, num_classes});

    // Get number of training samples
    int num_batches = d.GetSplit().size() / batch_size;

    d.SetSplit(SplitType::validation);

    // Get number of validation samples
    int num_batches_validation = d.GetSplit().size() / batch_size;

    cv::TickMeter tm;

    cout << "Starting training" << endl;
    for (int i = 0; i < epochs; ++i) {

        d.ResetAllBatches();

        d.SetSplit(SplitType::training);

        // Reset errors
        reset_loss(net);

        // Shuffle training list
        shuffle(d.GetSplit().begin(), d.GetSplit().end(), g);

        // Feed batches to the model
        for (int j = 0; j < num_batches; ++j) {
            cout << "Epoch " << i << "/" << epochs << " (batch " << j << "/" << num_batches << ") - ";
            tm.reset();
            tm.start();

            // Load a batch
            d.LoadBatch(x, y);

            // Preprocessing
            eddlT::div_(x, 255.0);

            // Train batch
            train_batch(net, { x }, { y });

            print_loss(net, j);
            tm.stop();
            cout << "- Elapsed time: " << tm.getTimeSec() << endl;
        }

        cout << "Saving model..." << endl;
	    save_net_to_onnx_file(net, "padchest_VGG16_adam_lr_0.0001.onnx");

        cout << "Starting validation:" << endl;
        d.SetSplit(SplitType::validation);

        // Reset errors
        reset_loss(net);

        // Validation for each batch
        for (int j = 0; j < num_batches_validation; ++j) {
            cout << "Validation - Epoch " << i << "/" << epochs << " (batch " << j << "/" << num_batches_validation << ") ";

            // Load a batch
            d.LoadBatch(x, y);

            // Preprocessing
            x->div_(255.);

            eval_batch(net, { x }, { y });
            print_loss(net, j);
            cout << endl;
        }
    }

    delete x;
    delete y;

    return EXIT_SUCCESS;
}
