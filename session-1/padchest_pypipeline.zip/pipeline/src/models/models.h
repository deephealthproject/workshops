#ifndef MODELS_H_
#define MODELS_H_

#include "ecvl/support_eddl.h"

// Model VGG16
eddl::layer VGG16(eddl::layer x, const int& num_classes);

#endif // MODELS_H_
