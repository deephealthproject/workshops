#include "models/models.h"
#include <eddl/serialization/onnx/eddl_onnx.h>

#include <algorithm>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <random>

using namespace ecvl;
using namespace eddl;
using namespace std;
using namespace std::filesystem;

int main()
{
    // Settings
    int batch_size = 16;
    int num_classes = 2;
    std::vector<int> size{ 256, 256 }; // Size of images

    // Load network
    model net = import_net_from_onnx_file("padchest_VGG16_adam_lr_0.0001.onnx");
    // Build model
    build(net,
        adam(0.0001), //Optimizer
        { "cross_entropy" }, // Losses
        { "categorical_accuracy" }, // Metrics
        CS_GPU({1}, "low_mem"), // Computing service
        false // To not reinitialize the weights
    );

    // View model
    summary(net);
    plot(net, "model_inference.pdf");
    setlogfile(net, "padchest_classification_inference");

    // Set augmentations for training and test
    auto test_augs = make_unique<SequentialAugmentationContainer>(AugResizeDim(size, InterpolationType::nearest));

    DatasetAugmentations dataset_augmentations{ {nullptr, nullptr, move(test_augs) } };

    // Read the dataset
    cout << "Reading dataset" << endl;
    DLDataset d("../../data/padchest.yml", batch_size, move(dataset_augmentations), ColorType::GRAY);

    // Prepare tensors which store batch
    tensor x = eddlT::create({ batch_size, d.n_channels_, size[0], size[1] });
    tensor y = eddlT::create({ batch_size, num_classes});

    // Get number of test samples.
    d.SetSplit(SplitType::test);
    int num_samples_test = d.GetSplit().size();
    int num_batches_test = num_samples_test / batch_size;

    cout << "Starting test:" << endl;

    // Test for each batch
    for (int i = 0, n = 0; i < num_batches_test; ++i) {
        cout << "Test - (batch " << i << "/" << num_batches_test << ") ";

        // Load a batch
        d.LoadBatch(x, y);

        // Preprocessing
        eddlT::div_(x, 255.0);

        eval_batch(net, { x }, { y });
        print_loss(net, i);

        cout << endl;
    }

    delete x;
    delete y;

    return EXIT_SUCCESS;
}
