from pyeddl.eddl import ReLu, MaxPool, Conv, Reshape, Softmax, Dense

def VGG16(in_tensor, num_classes):
    # Convolutional blocks
    x = ReLu(Conv(in_tensor, 64, [3, 3]))
    x = MaxPool(ReLu(Conv(x, 64, [3, 3])))
    x = ReLu(Conv(x, 128, [3, 3]))
    x = MaxPool(ReLu(Conv(x, 128, [3, 3])))
    x = ReLu(Conv(x, 256, [3, 3]))
    x = ReLu(Conv(x, 256, [3, 3]))
    x = MaxPool(ReLu(Conv(x, 256, [3, 3])))
    x = ReLu(Conv(x, 512, [3, 3]))
    x = ReLu(Conv(x, 512, [3, 3]))
    x = MaxPool(ReLu(Conv(x, 512, [3, 3])))
    x = ReLu(Conv(x, 512, [3, 3]))
    x = ReLu(Conv(x, 512, [3, 3]))
    x = MaxPool(ReLu(Conv(x, 512, [3, 3])))
    # Fully connected part
    x = Reshape(x, [-1])
    x = ReLu(Dense(x, 4096))
    x = ReLu(Dense(x, 4096))
    x = Softmax(Dense(x, num_classes))

    return x
