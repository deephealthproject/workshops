import sys
from pyeddl.eddl import ReLu, MaxPool, Conv, Reshape, Softmax, Dense, Dropout

def create_model(in_tensor, num_clases):
    #First conv layer

    x = ReLu(Conv(in_tensor, 32, [3,3]))
    x = MaxPool(x, [3,3], [2,2])
    
    x = ReLu(Conv(x, 64, [3,3]))
    x = MaxPool(x, [3,3], [2,2])

    x = ReLu(Conv(x, 128, [3,3]))
    x = MaxPool(x, [3,3], [2,2])

    x = ReLu(Conv(x, 128, [3,3]))
    x = MaxPool(x, [3,3], [2,2])

    x = ReLu(Conv(x, 32, [3,3]))
    x = MaxPool(x, [3,3], [2,2])
    
    #Flatten
    x = Reshape(x, [-1])
    x = Dropout(x, 0.5)

    #Classificiation
    x = ReLu(Dense(x, 512))
    x = Softmax(Dense(x, 2))

    return x
