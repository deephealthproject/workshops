import os
import sys
import numpy

import pandas
import keras
#from PIL import Image
import cv2
from skimage.transform import resize
from scipy.ndimage import shift, rotate, zoom

def myshift( img, offset=(1,1) ):
    if len(img.shape)==2:
        return shift( img, shift=offset )
    else:
        r = np.zeros( img.shape )
        for channel in range(img.shape[2]):
            r[:,:,channel] = shift( img[:,:,channel], shift=offset )
        return r

def myrotate( img, angle=0.0, reshape=False ):
    if len(img.shape)==2:
        return rotate( img, angle=angle, reshape=reshape )
    else:
        r = np.zeros( img.shape )
        for channel in range(img.shape[2]):
            r[:,:,channel] = rotate( img[:,:,channel], angle=angle, reshape=reshape )
        return r

def myzoom( img, factor=1.0 ):
    if len(img.shape)==2:
        return zoom( img, zoom=factor )
    else:
        r = []
        for channel in range(img.shape[2]):
            r.append( zoom( img[:,:,channel], zoom=factor ) )
        res=np.zeros( r[0].shape + (3,) )
        for i in range(len(r)):
            res[:,:,i] = r[i]
        return res


class DataGenerator(keras.utils.Sequence):
    'Generates batches of samples for Keras'
    def __init__( self, tsv_filename='etc/pneumo_dataset.tsv', data_dir='.', labels_filename='etc/labels.txt', partition='tr', batch_size=32, shuffle=True, verbose=False, gen_diffs=False, gen_fft2d=False ):
        '''
            Initialization

            partition: 'tr' = training, 'val' = validation, 'te' = test

            data_dir: where the image files are available

        '''
        self.verbose = verbose
        self.batch_size = batch_size
        self.shuffle = shuffle

        self.data_dir = data_dir

        self.gen_diffs=gen_diffs
        self.gen_fft2d=gen_fft2d

        self.in_channels = 1
        if self.gen_diffs: self.in_channels+=2
        if self.gen_fft2d: self.in_channels+=1

        if labels_filename is None:
            raise Exception( 'labels file must be provided' )
        
        self.labels=None
        try:
            f = open( labels_filename, 'r' )
            self.labels=dict()
            for line in f:
                key = line.strip()
                self.labels[key]=len(self.labels)
            f.close()
        except:
            raise Exception( 'labels file cannot be opened' )

        '''
        Columns:
            ImageID	StudyDate_DICOM	StudyID	PatientID	PatientBirth	PatientSex_DICOM	ViewPosition_DICOM	Projection	MethodProjection	Pediatric
            Modality_DICOM	Manufacturer_DICOM	PhotometricInterpretation_DICOM	PixelRepresentation_DICOM	PixelAspectRatio_DICOM
            SpatialResolution_DICOM	BitsStored_DICOM	WindowCenter_DICOM	WindowWidth_DICOM	Rows_DICOM	Columns_DICOM	XRayTubeCurrent_DICOM	
            Exposure_DICOM	ExposureInuAs_DICOM	ExposureTime	RelativeXRayExposure_DICOM
            Labels	group	Partition	
            Subject_occurrences	Partition_occurrences	Partitionlabel_occurrences
        '''
        df = pandas.read_csv( tsv_filename, sep='\t' )
        #print(df.columns)
        df['Partition'].fillna(value='tr',inplace=True)
        #
        data_filter  = df['Projection']=='PA'
        data_filter &= df['Partition']==partition
        data_filter &= df['group']!='I'
        data_filter &= df['group']!='NI'
        df_partition = df[ data_filter ]
        #
        if self.verbose:
            print( numpy.unique( df['group'].values ) )
            print( numpy.unique( df['Partition'].values ) )
        #
        self.groups=dict()
        for g in numpy.sort( numpy.unique( df['group'].values )):
            self.groups[g]=len(self.groups)
        #
        if self.verbose:
            print(self.groups)
        #
        self.groups['I'] = 1
        self.groups['N'] = 1
        self.groups['NI'] = 1
        #
        # sanity check
        #for c,n in zip(['C','I','N','NI'],[0,1,2,3]):
        for c,n in zip(['C','I','N','NI'],[0,1,1,1]):
            if self.groups[c] != n:
                print( self.groups )
                raise Exception( 'Groups find in data do not match the defined in the task!' )
        #
        self.Y=keras.utils.np_utils.to_categorical( numpy.array( [self.groups[g] for g in df_partition['group'] ], dtype=numpy.int32 ) )
        self.image_filenames=df_partition['ImageID'].values
        #
        Y_labels = []
        for l in df_partition['Labels']:
            l=l.replace('[','')
            l=l.replace(']','')
            mask = numpy.zeros(len(self.labels),dtype=numpy.int32)
            for w in [s.replace("'",'').strip() for s in l.split(sep=',')]:
                #print( "|%s|" % w, end=' ')
                if len(w) > 0: mask[ self.labels[w] ] = 1
            #print( mask )
            Y_labels.append(mask)
        #
        self.Y_labels = numpy.array( Y_labels )
        #
        self.indexes = numpy.arange(len(self.Y))
        #
        self.rows = self.columns = 200
        #
        self.on_epoch_end()
        #
        x,y = self.__getitem__(0)
        self.input_shape = x.shape[1:]
        #self.output_shape = ( self.Y.shape[1], self.Y_labels.shape[1] )
        self.output_shape = ( self.Y.shape[1], )
        #
        del df
        del df_partition

    def num_labels( self ): return len( self.labels )
    def num_groups( self ): return len( self.groups )

    def __len__( self ):
        'Denotes the number of batches per epoch'
        return 0 + len(self.Y) // self.batch_size

    def __getitem__( self, index ):
        'Generates one batch of data'
        #
        indexes=self.indexes[index*self.batch_size:(index+1)*self.batch_size]
        #
        X=[]
        Y1=[]
        Y2=[]
        for i in indexes:
            image = self.load_image( os.path.join( self.data_dir, self.image_filenames[i] ) )
            if image is not None:
                X.append( image )
                Y1.append( self.Y[i] )
                Y2.append( self.Y_labels[i] )
        X = numpy.array(X)
        Y1 = numpy.array(Y1)
        Y2 = numpy.array(Y2)
        #
        #return X, [Y1, Y2]
        return X, Y1


    def on_epoch_end( self ):
        'Updates indexes after each epoch'
        numpy.random.shuffle(self.indexes)

    def load_image(self, filename):
        image = cv2.imread( filename, cv2.IMREAD_UNCHANGED )
        #print( filename, type(image), image.max() )
        if image is not None:
            image = image/255.0
            #image = image.reshape( (200,200,1) )
            print(image.shape)
            if  image.shape != (self.rows,self.columns):
                raise Exception( 'Image size not expected!  ' + filename )
            x=numpy.zeros( image.shape + (self.in_channels,) )
            x[ :  , :  ,0] = image[ :  , :  ]
            channel=0
            n=8
            s=n//2
            k=2*n
            if self.gen_diffs:
                channel+=1
                x[s:-s, :  ,channel] = image[ :-n, :  ] - image[ n:  , :  ]
                channel+=1
                x[ :  ,s:-s,channel] = image[ :  , :-n] - image[  :  ,n:  ]
            if self.gen_fft2d:
                y = numpy.fft.fft2( image )
                #channel+=1
                #x[:,:,channel] = numpy.absolute(y) 
                channel+=1
                x[:,:,channel] = numpy.angle(y) 
            image = x[k:-k,k:-k,:]
            do_rotation = do_shift = do_zoom = False
            rotation_angle = 0.0
            shift_offset = (0,0)
            zoom_factor = 1.0
            if self.data_augmentation and np.random.rand() > 0.3: # Perform data augmentation
                do_rotation = np.random.rand() > 0.5
                do_shift    = np.random.rand() > 0.5
                do_zoom     = np.random.rand() > 0.5
                rotation_angle = np.random.randint(40+1)-30 if do_rotation else 0.0
                shift_offset   = ( np.random.randint(100)-80, np.random.randint(100)-80 ) if do_shift else (0,0)
                zoom_factor    = 0.1 + np.random.rand()*0.1 if do_zoom else 0.0
        #

        if do_zoom:
            image_resampled = myzoom( image, factor=zoom_factor )
        if do_rotation:
            image_resampled = myrotate( image_resampled, angle=rotation_angle, reshape=False )
        if do_shift:
            image_resampled = myshift( image_resampled, offset=shift_offset )
        return image_resampled



if __name__ == '__main__':
    dg = DataGenerator( data_dir='projects/ceib/padchest_covid19/resized_img_200', partition='tr', gen_diffs=True, gen_fft2d=True )

    for i in range(len(dg)):
        x,y = dg.__getitem__(i)
        print(i, x.shape, y[0].shape, y[1].shape)
